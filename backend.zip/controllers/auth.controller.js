const {
  generateOTP,
  OTP_EXPIRY_MINUTES,
  sendOTP,
  hashOTP,
} = require("../services/otp.service");
const User = require("../models/User.model");
const Garage = require("../models/Garage.model");
const asyncHandler = require("../utils/asyncHandler");
const {
  signAccessToken,
  generateAndSaveRefreshToken,
  rotateRefreshToken,
  revokeRefreshToken,
} = require("../utils/token.utils");
const { sendSuccess, sendError } = require("../utils/response.utils");

// ─── Cookie config — defined once, reused everywhere ──────────────
const REFRESH_COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "strict",
  maxAge: 7 * 24 * 60 * 60 * 1000,
};

// ─────────────────────────────────────────────────────────────────
//  Step 1 · Request OTP
//  Creates a user document (upsert) tied to the phone number and
//  fires the OTP.  No sensitive data is returned in production.
// ─────────────────────────────────────────────────────────────────
const requestOTP = asyncHandler(async (req, res) => {
  const { phoneNo } = req.body;

  const otp = generateOTP();
  const expiresAt = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);

  await User.findOneAndUpdate(
    { phoneNo },
    { otp: { code: hashOTP(otp), expiresAt, attempts: 0 } },
    { upsert: true, returnDocument: "after" },
  );

  await sendOTP(phoneNo, otp);

  return sendSuccess(res, 200, "OTP sent successfully", otp);
});

// ─────────────────────────────────────────────────────────────────
//  Step 2 · Verify OTP
//  Validates the OTP, marks the user as verified, and issues tokens.
// ─────────────────────────────────────────────────────────────────
const verifyOTP = asyncHandler(async (req, res) => {
  const { phoneNo, otp } = req.body;

  const user = await User.findOne({ phoneNo });

  if (!user || !user.otp?.code)
    return sendError(res, 404, "No OTP found. Request a new one.");

  if (user.otp.attempts >= 3)
    return sendError(res, 429, "Too many attempts. Request a new OTP.");

  if (new Date() > user.otp.expiresAt)
    return sendError(res, 400, "OTP expired. Request a new one.");

  if (user.otp.code !== hashOTP(otp)) {
    await User.updateOne({ phoneNo }, { $inc: { "otp.attempts": 1 } });
    return sendError(res, 400, "Invalid OTP");
  }

  await User.updateOne({ phoneNo }, { isVerified: true, $unset: { otp: "" } });

  const verifiedUser = await User.findOne({ phoneNo });

  const accessToken = signAccessToken(verifiedUser);
  const refreshToken = await generateAndSaveRefreshToken(verifiedUser);

  res.cookie("refreshToken", refreshToken, REFRESH_COOKIE_OPTIONS);

  const garage = await Garage.findOne({ owner: verifiedUser._id }).lean();

  return sendSuccess(res, 200, "Mobile verified successfully", {
    accessToken,
    isProfileComplete: garage?.isProfileComplete ?? false,
    user: verifiedUser,
    garage: garage ?? null,
  });
});

// ─────────────────────────────────────────────────────────────────
//  Step 3 · Resend OTP
//  Rate-limited to one resend per 60 seconds.
// ─────────────────────────────────────────────────────────────────
const resendOTP = asyncHandler(async (req, res) => {
  const { phoneNo } = req.body;

  const user = await User.findOne({ phoneNo });

  if (!user)
    return sendError(
      res,
      404,
      "No account found with this number. Request OTP first.",
    );

  // Enforce 60-second cooldown between resend requests
  if (user.otp?.expiresAt) {
    const otpLifetimeMs = OTP_EXPIRY_MINUTES * 60 * 1000;
    const otpCreatedAt = new Date(user.otp.expiresAt).getTime() - otpLifetimeMs;
    const secondsSinceSent = (Date.now() - otpCreatedAt) / 1000;

    if (secondsSinceSent < 60) {
      const waitSeconds = Math.ceil(60 - secondsSinceSent);
      return sendError(
        res,
        429,
        `Please wait ${waitSeconds} seconds before requesting a new OTP.`,
      );
    }
  }

  const otp = generateOTP();
  const expiresAt = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);

  await User.updateOne(
    { phoneNo },
    { otp: { code: hashOTP(otp), expiresAt, attempts: 0 } },
  );

  await sendOTP(phoneNo, otp);

  return sendSuccess(res, 200, "OTP resent successfully", otp);
});

// ─────────────────────────────────────────────────────────────────
//  Step 4 · Complete Garage Profile
//
//  Accepts multipart/form-data OR application/json (the Zod validator
//  handles both after the body is parsed by express.json / multer).
// ─────────────────────────────────────────────────────────────────
const completeGarageProfile = asyncHandler(async (req, res) => {
  // Only owners can set garage details
  if (req.user.role !== "owner")
    return sendError(res, 403, "Only owners can set garage details");

  const userId = req.user._id;

  const {
    // User-level fields
    fullName,
    emailId,
    state,
    // Garage-level fields
    garageName,
    garageOwnerName,
    garageAddress,
    garageContactNumber,
    garageType,
    garageLogo,
    isGstApplicable,
    gstNumber,
  } = req.body;

  // ── 1. Update user profile fields ──────────────────────────────
  const updatedUser = await User.findByIdAndUpdate(
    userId,
    {
      ...(fullName !== undefined && { fullName }),
      ...(emailId !== undefined && { emailId }),
      ...(state !== undefined && { state }),
    },
    { new: true, runValidators: true },
  );

  // ── 2. Upsert garage document ───────────────────────────────────
  //  findOneAndUpdate with upsert handles both first-time setup and
  //  subsequent edits without the controller caring which case it is.
  const garagePayload = {
    garageName,
    garageOwnerName,
    garageAddress,
    garageContactNumber,
    garageType,
    isGstApplicable: !!isGstApplicable,
    gstNumber: isGstApplicable ? (gstNumber ?? null) : null,
    isProfileComplete: true,
    ...(garageLogo !== undefined && { garageLogo }),
    ...(state !== undefined && { state }),
  };

  const garage = await Garage.findOneAndUpdate(
    { owner: userId },
    { $set: garagePayload },
    { upsert: true, new: true, runValidators: true },
  );

  return sendSuccess(res, 200, "Garage profile completed", {
    user: updatedUser,
    garage,
  });
});

// ─────────────────────────────────────────────────────────────────
//  GET /auth/garage  — return current user's garage
// ─────────────────────────────────────────────────────────────────
const getMyGarage = asyncHandler(async (req, res) => {
  const garage = await Garage.findOne({ owner: req.user._id }).lean();
  if (!garage) return sendError(res, 404, "Garage not found.");
  return sendSuccess(res, 200, "Garage fetched.", { garage });
});

// ─────────────────────────────────────────────────────────────────
//  Refresh Access Token
// ─────────────────────────────────────────────────────────────────
const refresh = asyncHandler(async (req, res) => {
  const incomingToken = req.cookies?.refreshToken;

  if (!incomingToken) return sendError(res, 401, "No refresh token.");

  const result = await rotateRefreshToken(incomingToken);

  if (!result.success) return sendError(res, 401, result.message);

  res.cookie("refreshToken", result.refreshToken, REFRESH_COOKIE_OPTIONS);

  return sendSuccess(res, 200, "Token refreshed", {
    accessToken: result.accessToken,
  });
});

// ─────────────────────────────────────────────────────────────────
//  Logout
// ─────────────────────────────────────────────────────────────────
const logout = asyncHandler(async (req, res) => {
  await revokeRefreshToken(req.user._id);
  res.clearCookie("refreshToken");
  return sendSuccess(res, 200, "Logged out successfully");
});

// ─────────────────────────────────────────────────────────────────
//  POST /auth/upload-image  — upload a garage logo / image
//  Accepts multipart/form-data with field "file" (image only, ≤5MB)
//  Returns { url } — the publicly accessible URL of the stored file
// ─────────────────────────────────────────────────────────────────
const uploadImage = asyncHandler(async (req, res) => {
  if (!req.file) return sendError(res, 400, "No file uploaded.");
  const url = `${req.protocol}://${req.get("host")}/uploads/${req.file.filename}`;
  return sendSuccess(res, 200, "Image uploaded successfully", { url });
});

// ─────────────────────────────────────────────────────────────────
//  PATCH /auth/preferences  — save garage app preferences
//  Body: { notificationsEnabled, autoUpdates, autoWaNotification, fontSize }
// ─────────────────────────────────────────────────────────────────
const updatePreferences = asyncHandler(async (req, res) => {
  if (req.user.role !== "owner") return sendError(res, 403, "Only owners can update preferences.");

  const garage = await Garage.findOne({ owner: req.user._id });
  if (!garage) return sendError(res, 404, "Garage not found.");

  const allowed = ["notificationsEnabled", "autoUpdates", "autoWaNotification", "fontSize"];
  const validFontSizes = ["small", "medium", "large"];

  if (!garage.preferences) garage.preferences = {};

  for (const key of allowed) {
    if (req.body[key] === undefined) continue;
    if (key === "fontSize" && !validFontSizes.includes(req.body[key])) continue;
    garage.preferences[key] = req.body[key];
  }

  garage.markModified("preferences");
  await garage.save();

  return sendSuccess(res, 200, "Preferences saved.", { preferences: garage.preferences });
});

module.exports = {
  requestOTP,
  verifyOTP,
  resendOTP,
  completeGarageProfile,
  getMyGarage,
  refresh,
  logout,
  uploadImage,
  updatePreferences,
};
